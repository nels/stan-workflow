#ifndef STAN_LANG_GRAMMARS_VAR_DECLS_GRAMMAR_HPP
#define STAN_LANG_GRAMMARS_VAR_DECLS_GRAMMAR_HPP
#include "local_vars_decls_grammar.hpp"
#include "block_var_decls_grammar.hpp"
#endif
