
#* @get /foo
fooRoute <- function() {
    "hello world"
}
