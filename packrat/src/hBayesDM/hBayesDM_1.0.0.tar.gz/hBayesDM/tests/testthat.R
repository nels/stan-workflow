library(testthat)
library(hBayesDM)

test_check("hBayesDM")
